package com.dengjia.lib_share_asr.asr_skill;

public enum SkillType {

    DEVICE_CONTROL_SKILL();


}
