package com.dengjia.lib_share_asr.asr_skill.Entity;

import java.util.List;

public interface IEntity {
    List<String> getEntitiess();
}
