package com.dengjia.lib_share_asr.asr_skill;

public abstract class BaseSkill implements IAsrSkill{

}
