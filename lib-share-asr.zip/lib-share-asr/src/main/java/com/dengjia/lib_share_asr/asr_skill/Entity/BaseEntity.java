package com.dengjia.lib_share_asr.asr_skill.Entity;

public abstract class BaseEntity implements IEntity {
}
