package com.dengjia.lib_share_asr.asr_skill;

import com.dengjia.lib_share_asr.asr_skill.Entity.BaseEntity;

import java.util.HashMap;

public interface IAsrSkill {
    HashMap<Integer, BaseEntity> getEntityList();
}
